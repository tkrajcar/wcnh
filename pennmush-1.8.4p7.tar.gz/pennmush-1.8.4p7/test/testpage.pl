run tests:
test('page.1', $god, 'page/noeval %# \= =',"I can't find"); # Former crasher
