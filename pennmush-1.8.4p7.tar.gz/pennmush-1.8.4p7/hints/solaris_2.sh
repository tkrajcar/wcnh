ccflags="-DNO_SIGCONTEXT"
libs="-lnsl -lsocket -lm -lc -lresolv" 
i_fcntl="define"
has_sigchld="define"
